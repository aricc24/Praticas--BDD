"""
Enumeraciones utilizadas en la aplicación para la interacción con el usuario.
Contiene constantes y valores fijos para consultas y tipos de entidades.
"""