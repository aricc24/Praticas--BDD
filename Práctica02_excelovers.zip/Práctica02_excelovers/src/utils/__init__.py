"""
Paquete de utilidades generales.
Incluye validadores y excepciones personalizadas para toda la aplicación.
"""
