"""
Validadores de datos.
Funciones y clases para verificar la validez de entradas de usuario.
"""
