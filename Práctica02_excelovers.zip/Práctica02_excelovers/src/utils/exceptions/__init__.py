"""
Excepciones personalizadas.
Define errores específicos del dominio y la infraestructura.
"""
