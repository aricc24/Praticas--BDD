"""
Paquete de dominio de la aplicación.
Define las partes de la lógica de la aplicación.
"""
