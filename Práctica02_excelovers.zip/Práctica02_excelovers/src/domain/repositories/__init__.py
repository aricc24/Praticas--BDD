"""
Interfaces de repositorios del dominio.
Define contratos (interfaces) para operaciones de lectura/escritura de entidades.
"""
