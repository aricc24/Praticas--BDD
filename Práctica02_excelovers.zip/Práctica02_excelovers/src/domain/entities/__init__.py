"""
Entidades del dominio del torneo de Pokémon.
Incluye clases que representan cuentas, participantes y Pokémones.
"""
