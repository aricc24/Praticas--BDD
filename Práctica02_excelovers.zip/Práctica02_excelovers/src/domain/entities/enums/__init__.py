"""
Enumeraciones usadas en la aplicación.
Contiene constantes y valores fijos para consultas y tipos de entidades.
"""
