"""
Paquete raíz de la aplicación de manejo  de datos del torneo Pokemon del equipo Excelovers.
Contiene todos los subpaquetes: dominio, aplicación, infraestructura, presentación y utilidades.
"""
