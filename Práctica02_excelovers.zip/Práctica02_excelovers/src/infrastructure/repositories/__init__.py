"""
Repositorios concretos que controlan el acceso a datos.
Implementan persistencia mediante CSV de la información de la aplicación.
"""
