"""
Paquete de infraestructura.
Incluye manejadores de archivos y repositorios concretos que implementan las interfaces del dominio para el acceso a datos.
"""
