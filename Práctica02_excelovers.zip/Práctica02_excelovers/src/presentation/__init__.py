"""
Paquete de presentación de la aplicación.
Contiene interfaces de usuario: CLI y GUI, así como menús y handlers de eventos.
"""
