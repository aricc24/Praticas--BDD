"""
Interfaz gráfica de usuario (GUI).
Contiene ventanas gráficas para gestionar cuentas, participantes y Pokémon.
"""
