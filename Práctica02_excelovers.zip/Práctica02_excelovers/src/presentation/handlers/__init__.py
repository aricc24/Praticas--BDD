"""
Contiene las funciones que manejan los eventos de la interfaz CLI.
"""