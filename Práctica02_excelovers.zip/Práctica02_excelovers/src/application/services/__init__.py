"""
Servicios de aplicación.
Contiene los manejadores de las operaciones posibles de la aplicación.
"""