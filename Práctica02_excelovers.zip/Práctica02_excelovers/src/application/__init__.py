"""
Modulo de aplicación.
Contiene los servicios que manejan las operaciones posibles de la aplicación.
"""